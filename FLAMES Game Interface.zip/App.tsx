import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import FlamesIntro from './components/FlamesIntro';
import NameInput from './components/NameInput';
import ResultCards from './components/ResultCards';
import backgroundImage from 'figma:asset/9f1c6fdd3986ec0194797951b250c51a3073c338.png';
import cosmicBackground from 'figma:asset/ca17b6f4bd0b047e3237295b120bdb7377933c92.png';

export type FlamesResult = 'F' | 'L' | 'A' | 'M' | 'E' | 'S';

export interface FlamesGameState {
  part: 1 | 2 | 3;
  name1: string;
  name2: string;
  result: FlamesResult | null;
}

const flamesMapping = {
  F: 'Friends',
  L: 'Lovers',
  A: 'Affection', 
  M: 'Marriage',
  E: 'Enemy',
  S: 'Siblings'
};

function calculateFlames(name1: string, name2: string): FlamesResult {
  // Convert to lowercase and remove spaces
  const n1 = name1.toLowerCase().replace(/\s/g, '');
  const n2 = name2.toLowerCase().replace(/\s/g, '');
  
  // Create character count maps
  const charCount1: { [key: string]: number } = {};
  const charCount2: { [key: string]: number } = {};
  
  for (const char of n1) {
    charCount1[char] = (charCount1[char] || 0) + 1;
  }
  
  for (const char of n2) {
    charCount2[char] = (charCount2[char] || 0) + 1;
  }
  
  // Remove common characters
  let uncommonCount = 0;
  
  // Count remaining characters from name1
  for (const char in charCount1) {
    const commonCount = Math.min(charCount1[char], charCount2[char] || 0);
    uncommonCount += charCount1[char] - commonCount;
  }
  
  // Count remaining characters from name2
  for (const char in charCount2) {
    const commonCount = Math.min(charCount2[char], charCount1[char] || 0);
    uncommonCount += charCount2[char] - commonCount;
  }
  
  // FLAMES elimination process
  const flames = ['F', 'L', 'A', 'M', 'E', 'S'];
  let currentIndex = 0;
  
  while (flames.length > 1) {
    // Calculate the index to eliminate (uncommonCount - 1 steps from current)
    const eliminateIndex = (currentIndex + uncommonCount - 1) % flames.length;
    flames.splice(eliminateIndex, 1);
    
    // Update current index after elimination
    currentIndex = eliminateIndex % flames.length;
  }
  
  return flames[0] as FlamesResult;
}

export default function App() {
  const [gameState, setGameState] = useState<FlamesGameState>({
    part: 1,
    name1: '',
    name2: '',
    result: null
  });

  const handleIntroComplete = () => {
    setGameState(prev => ({ ...prev, part: 2 }));
  };

  const handleNamesSubmit = (name1: string, name2: string) => {
    const result = calculateFlames(name1, name2);
    setGameState(prev => ({
      ...prev,
      name1,
      name2,
      result,
      part: 3
    }));
  };

  const handleRestart = () => {
    setGameState({
      part: 1,
      name1: '',
      name2: '',
      result: null
    });
  };

  // Choose background based on current part
  const currentBackground = gameState.part === 3 ? cosmicBackground : backgroundImage;

  return (
    <div 
      className="min-h-screen w-full dark relative overflow-hidden transition-all duration-1000"
      style={{
        backgroundImage: `url(${currentBackground})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      {/* Dynamic overlay - darker for cosmic background */}
      <div className={`absolute inset-0 transition-all duration-1000 ${
        gameState.part === 3 ? 'bg-black/60' : 'bg-black/50'
      }`} />
      
      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <AnimatePresence mode="wait">
          {gameState.part === 1 && (
            <motion.div
              key="intro"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full"
            >
              <FlamesIntro onComplete={handleIntroComplete} />
            </motion.div>
          )}
          
          {gameState.part === 2 && (
            <motion.div
              key="input"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              className="w-full"
            >
              <NameInput onSubmit={handleNamesSubmit} />
            </motion.div>
          )}
          
          {gameState.part === 3 && (
            <motion.div
              key="result"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="w-full"
            >
              <ResultCards 
                name1={gameState.name1}
                name2={gameState.name2}
                result={gameState.result!}
                resultText={flamesMapping[gameState.result!]}
                onRestart={handleRestart}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}